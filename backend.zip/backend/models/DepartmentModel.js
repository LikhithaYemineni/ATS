const mongoose = require('mongoose');
// const uri = "mongodb+srv://likhithayemineni143:Waterloo@cluster0.8x4jgla.mongodb.net/ATS?retryWrites=true&w=majority";

// mongoose.connect(uri,{
//     useNewUrlParser:true,
//     useUnifiedTopology:true
// }).then(()=>{console.log("Connected to MongoDb")})
// .catch((err)=>{console.log(`not connected to MongoDb due to error below \n ${err}`)})

const departmentSchema = new mongoose.Schema({
  name: {type:String},
  jobId: { type: mongoose.Types.ObjectId, 
         ref: 'JobModel' },
});

const DepartmentModel = mongoose.model('Department', departmentSchema);
module.exports = DepartmentModel;